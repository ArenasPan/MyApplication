package com.oschina.tianditu.myapplication;

/**
 * Created by sina on 2015/7/16.
 */
public class DataInput {
    private String name;
    private String description;
    private String info;
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }
    public void setDescription(String description){
        this.description = description;
    }
    public String getDescription(){
        return description;
    }
    public void setInfo(String info){
        this.info = info;
    }
    public String getInfo(){
        return info;
    }
}
