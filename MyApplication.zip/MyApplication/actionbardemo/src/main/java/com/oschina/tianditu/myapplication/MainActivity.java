package com.oschina.tianditu.myapplication;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends ActionBarActivity {
    ArrayList<DataInput> data_list = new ArrayList<DataInput>();
    MyAdapter adapter;
    ListView lv;
    android.support.v7.app.ActionBar mactionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mactionBar = getSupportActionBar();
        mactionBar.setDisplayHomeAsUpEnabled(true);
        getData();
        showListView(data_list);
    }

    private void showListView(ArrayList<DataInput> dataInputs) {
        if (adapter == null) {
            lv = (ListView) findViewById(R.id.listView);
            adapter = new MyAdapter(this, dataInputs);
            lv.setAdapter(adapter);
        } else {
            adapter.onDataChange(dataInputs);
        }
    }

    private void getData() {
        for (int i = 0; i < 5; i++) {
            DataInput inputData = new DataInput();
            inputData.setName("project" + i);
            inputData.setInfo("developer" + i);
            inputData.setDescription("description: This is an android project");
            data_list.add(inputData);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        //��Ӳ˵���
        MenuItem add = menu.add(0, 0, 0, "add");
        MenuItem del = menu.add(0, 1, 0, "del");
        MenuItem save = menu.add(0, 2, 0, "save");
        //�󶨵�ActionBar
        add.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        del.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        save.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()){
            case 0:
                Toast.makeText(this,"add clicked",Toast.LENGTH_SHORT).show();
                break;
            case 1:
                Toast.makeText(this,"del clicked",Toast.LENGTH_SHORT).show();
                break;
            case 2:
                Toast.makeText(this,"save clicked",Toast.LENGTH_SHORT).show();
                break;
            case R.id.action_settings:
                Toast.makeText(this,"setting clicked",Toast.LENGTH_SHORT).show();
                break;
            case android.R.id.home:
                Toast.makeText(this,"home clicked",Toast.LENGTH_SHORT).show();
                break;
            default:
                break;
        }

//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
        return super.onOptionsItemSelected(item);
    }
}
