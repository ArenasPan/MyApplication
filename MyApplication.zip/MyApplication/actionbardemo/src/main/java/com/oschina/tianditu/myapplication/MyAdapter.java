package com.oschina.tianditu.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by sina on 2015/7/16.
 */
public class MyAdapter extends BaseAdapter {
    private MainActivity main;
    ArrayList<DataInput> data_list;
    LayoutInflater inflater;
    ViewHolder viewHolder;
    private Context mContext;


    public MyAdapter(Context context, ArrayList<DataInput> dataInputs) {
        this.mContext = context;
        this.data_list = dataInputs;
        this.inflater = LayoutInflater.from(context);
    }

    public void onDataChange(ArrayList<DataInput> dataInputs) {
        this.data_list = dataInputs;
        this.notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return data_list.size();
    }

    @Override
    public Object getItem(int position) {
        return data_list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

//    public void removeItem(int position){
//        data_list.remove(position);
//        this.notifyDataSetChanged();
//    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        DataInput inputData = data_list.get(position);
        //将列表项的信息储存在viewHolder中，将数据添加到其中并传给convertView
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_layout, null);
            viewHolder = new ViewHolder();
            viewHolder.name_show = (TextView) convertView.findViewById(R.id.name);
            viewHolder.info_show = (TextView) convertView.findViewById(R.id.info);
            viewHolder.des_show = (TextView) convertView.findViewById(R.id.des);
            viewHolder.btn = (Button) convertView.findViewById(R.id.button);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.name_show.setText(inputData.getName());
        viewHolder.info_show.setText(inputData.getInfo());
        viewHolder.des_show.setText(inputData.getDescription());
        viewHolder.btn.setOnClickListener(new lvButtonListener(position));
        return convertView;
    }

    class lvButtonListener implements View.OnClickListener {
        private int position;
        lvButtonListener(int pos) {
            position = pos;
        }
        @Override
        public void onClick(View v) {
            if (mContext != null) {
                Intent intent = new Intent(mContext, DetailsInfomation.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mContext.startActivity(intent);
            }
        }
    }

    class ViewHolder {
        TextView name_show;
        TextView info_show;
        TextView des_show;
        Button btn;
    }
}
