package com.oschina.tianditu.myapplication;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by sina on 2015/7/17.
 */
public class TabTwo extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_two);
    }
}
