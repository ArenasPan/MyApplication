package com.oschina.tianditu.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MainActivity extends Activity {
    private ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (ListView) findViewById(R.id.listView);
        SimpleAdapter adapter = new SimpleAdapter(this,getData(), R.layout.lview, new String[]{"title", "info", "image"}, new int[]{R.id.title, R.id.info, R.id.image});
        lv.setAdapter(adapter);
    }

    private List<Map<String,Object>> getData(){
        List<Map<String,Object>> list = new ArrayList<Map<String, Object>>();

        Map<String, Object> map1 = new HashMap<String, Object>();
        map1.put("title", "1");
        map1.put("info","first");
        map1.put("image", R.drawable.i1);
        list.add(map1);

        Map<String, Object> map2 = new HashMap<String, Object>();
        map2.put("title", "2");
        map2.put("info","second");
        map2.put("image", R.drawable.i2);
        list.add(map2);

        Map<String, Object> map3 = new HashMap<String, Object>();
        map3.put("title", "3");
        map3.put("info","third");
        map3.put("image", R.drawable.i3);
        list.add(map3);
        return list;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
