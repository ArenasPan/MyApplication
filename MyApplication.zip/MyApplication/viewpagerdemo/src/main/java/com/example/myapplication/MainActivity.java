package com.example.myapplication;


import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.PagerTabStrip;
import android.support.v4.view.PagerTitleStrip;
import android.support.v4.view.ViewPager;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends android.support.v4.app.FragmentActivity {
    private ViewPager mViewPager;
    private fragment1 mfragment1;
    private fragment2 mfragment2;
    private fragment3 mfragment3;
    //页面列表
    private ArrayList<android.support.v4.app.Fragment> fragmentList;
    //标题列表
    ArrayList<String> titleList = new ArrayList<String>();
    //通过pagerTabStrip可以设置标题的属性
    private PagerTabStrip pagerTabStrip;
    private PagerTitleStrip pagerTitleStrip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mViewPager = (ViewPager) findViewById(R.id.viewpager);
        pagerTabStrip = (PagerTabStrip) findViewById(R.id.pagertap);
        pagerTabStrip.setTabIndicatorColor(getResources().getColor(android.R.color.holo_green_dark));
        pagerTabStrip.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_dark));

        mfragment1 = new fragment1();
        mfragment2 = new fragment2();
        mfragment3 = new fragment3();

        fragmentList = new ArrayList<android.support.v4.app.Fragment>();
        fragmentList.add(mfragment1);
        fragmentList.add(mfragment2);
        fragmentList.add(mfragment3);

        titleList.add("tab1");
        titleList.add("tab2");
        titleList.add("tab3");

        mViewPager.setAdapter(new MyViewPagerAdapter(getSupportFragmentManager()));
    }

    public class MyViewPagerAdapter extends FragmentPagerAdapter{

        public MyViewPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public android.support.v4.app.Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titleList.get(position);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
