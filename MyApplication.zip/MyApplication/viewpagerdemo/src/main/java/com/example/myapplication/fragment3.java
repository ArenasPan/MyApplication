package com.example.myapplication;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by Administrator on 2015/7/19.
 */
public class fragment3 extends android.support.v4.app.Fragment {
    private View mMainView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.v("huahua", "fragment3-->onCreate()");

        LayoutInflater inflater =getActivity().getLayoutInflater();
        mMainView = inflater.inflate(R.layout.lay3, (ViewGroup) getActivity().findViewById(R.id.viewpager), false);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.v("huahua", "fragment3-->onCreateView()");

        ViewGroup vg = (ViewGroup) mMainView.getParent();
        if (vg != null) {
            vg.removeAllViewsInLayout();
            Log.v("huahua", "fragment3-->移除已存在的View");
        }
        return mMainView;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.v("huahua", "fragment3-->onDestroy()");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.v("huahua", "fragment3-->onPause()");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.v("huahua", "fragment3-->onResume()");
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.v("huahua", "fragment3-->onStart()");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.v("huahua", "fragment3-->onStop()");
    }
}
