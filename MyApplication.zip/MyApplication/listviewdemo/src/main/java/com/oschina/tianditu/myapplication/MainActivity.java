package com.oschina.tianditu.myapplication;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity implements View.OnClickListener {
    //    ArrayList<DataInput> data_list = new ArrayList<DataInput>();
//    MyAdapter adapter;
    //    ListView lv;
    private HotFragment hotFragment;
    private NewFragment newFragment;
    private RecommendFragment recommendFragment;

    private ActionBar mActionBar;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mActionBarDrawerToggle;

    View hotLayout;
    View newLayout;
    View recommendLayout;
    TextView hotText;
    TextView newText;
    TextView recommendText;
    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragmentview);
        mActionBar = getSupportActionBar();
        mActionBar.setTitle("发现");
        mActionBar.setDisplayHomeAsUpEnabled(true);

        fragmentManager = getFragmentManager();
        initView();
        setTabSelection(0);

        mDrawerLayout.setDrawerListener(new MyDrawerListener());
        this.mActionBarDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, null, 0, 0);

    }

    private class MyDrawerListener implements DrawerLayout.DrawerListener {

        @Override
        public void onDrawerSlide(View drawerView, float slideOffset) {
            mActionBarDrawerToggle.onDrawerSlide(drawerView,slideOffset);
        }

        @Override
        public void onDrawerOpened(View drawerView) {
            mActionBarDrawerToggle.onDrawerOpened(drawerView);
        }

        @Override
        public void onDrawerClosed(View drawerView) {
            mActionBarDrawerToggle.onDrawerClosed(drawerView);
        }

        @Override
        public void onDrawerStateChanged(int newState) {
            mActionBarDrawerToggle.onDrawerStateChanged(newState);
        }
    }

    private void initView() {
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        hotLayout = findViewById(R.id.hot_layout);
        hotLayout.setOnClickListener(this);
        newLayout = findViewById(R.id.new_layout);
        newLayout.setOnClickListener(this);
        recommendLayout = findViewById(R.id.recommend_layout);
        recommendLayout.setOnClickListener(this);
        hotText = (TextView) findViewById(R.id.hot_text);
        newText = (TextView) findViewById(R.id.new_text);
        recommendText = (TextView) findViewById(R.id.recommend_text);
    }

//    private void showListView(ArrayList<DataInput> dataInputs) {
//        if (adapter == null) {
//            lv = (ListView) findViewById(R.id.listView);
//            adapter = new MyAdapter(this, dataInputs);
//            lv.setAdapter(adapter);
//        } else {
//            adapter.onDataChange(dataInputs);
//        }
//    }
//
//    private void getData() {
//        for (int i = 0; i < 5; i++) {
//            DataInput inputData = new DataInput();
//            inputData.setName("项目名称" + i);
//            inputData.setInfo("上传者" + i);
//            inputData.setDescription("程序描述: 这是一个安卓应用程序");
//            data_list.add(inputData);
//        }
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mActionBarDrawerToggle.syncState();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
        //点击三横线会弹出DrawerLayout,反之会收起
        if(mActionBarDrawerToggle.onOptionsItemSelected(item))
        {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

//    public void showNewIntent() {
//        Intent intent = new Intent(MainActivity.this, DetailsInfomation.class);
//        startActivity(intent);
//    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.hot_layout:
                setTabSelection(0);
                break;
            case R.id.new_layout:
                setTabSelection(1);
                break;
            case R.id.recommend_layout:
                setTabSelection(2);
                break;
            default:
                break;
        }
    }

    private void setTabSelection(int index) {
        clearSelection();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        hideFragments(fragmentTransaction);
        switch (index) {
            case 0:
                hotText.setTextColor(Color.WHITE);
                if (hotFragment == null) {
                    hotFragment = new HotFragment();
                    fragmentTransaction.add(R.id.content, hotFragment);
                } else {
                    fragmentTransaction.show(hotFragment);
                }
                fragmentTransaction.commit();
                break;
            case 1:
                newText.setTextColor(Color.WHITE);
                if (newFragment == null) {
                    newFragment = new NewFragment();
                    fragmentTransaction.add(R.id.content, newFragment);
                } else {
                    fragmentTransaction.show(newFragment);
                }
                fragmentTransaction.commit();
                break;
            case 2:
                recommendText.setTextColor(Color.WHITE);
                if (recommendFragment == null) {
                    recommendFragment = new RecommendFragment();
                    fragmentTransaction.add(R.id.content, recommendFragment);
                } else {
                    fragmentTransaction.show(recommendFragment);
                }
                fragmentTransaction.commit();
                break;
            default:
                break;
        }
    }

    private void clearSelection() {
        hotText.setTextColor(Color.parseColor("#82858b"));
        newText.setTextColor(Color.parseColor("#82858b"));
        recommendText.setTextColor(Color.parseColor("#82858b"));
    }

    private void hideFragments(FragmentTransaction transaction) {
        if (hotFragment != null) {
            transaction.hide(hotFragment);
        }
        if (newFragment != null) {
            transaction.hide(newFragment);
        }
        if (recommendFragment != null) {
            transaction.hide(recommendFragment);
        }

    }
}
