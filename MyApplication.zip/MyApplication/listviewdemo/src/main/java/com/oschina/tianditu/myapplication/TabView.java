package com.oschina.tianditu.myapplication;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TabHost;

/**
 * Created by sina on 2015/7/17.
 */
public class TabView extends TabActivity{
    private TabHost tabHost;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tabview);
        tabHost = getTabHost();

        TabHost.TabSpec tab1 = tabHost.newTabSpec("tabone");
        tab1.setIndicator("tab1");
        Intent intent = new Intent();
        intent.setClass(this, MainActivity.class);
        tab1.setContent(intent);
        tabHost.addTab(tab1);

        TabHost.TabSpec tab2 = tabHost.newTabSpec("tabtwo");
        tab2.setIndicator("tab2");
        Intent intent2 = new Intent();
        intent2.setClass(this,MainActivity.class);
        tab2.setContent(intent);
        tabHost.addTab(tab2);

        TabHost.TabSpec tab3 = tabHost.newTabSpec("tabthree");
        tab3.setIndicator("");
        Intent intent3 = new Intent();
        intent3.setClass(this,MainActivity.class);
        tab3.setContent(intent);
        tabHost.addTab(tab3);
    }
}
