package com.oschina.tianditu.myapplication;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by sina on 2015/7/20.
 */

/**
 * @���� ��Fragment��Ҫʹ��ListView����Ҫ��ListFragment
 */
public class HotFragment extends Fragment {

    ArrayList<DataInput> data_list = new ArrayList<DataInput>();
    MyAdapter adapter;
    ListView lv;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View hotFragment = inflater.inflate(R.layout.activity_main, container, false);
        lv = (ListView) hotFragment.findViewById(R.id.listView);
        getData();
        if (adapter == null) {
            adapter = new MyAdapter(getActivity().getApplicationContext(), data_list);
            lv.setAdapter(adapter);
        } else {
            adapter.onDataChange(data_list);
        }
        return hotFragment;
    }

    private void getData() {
        for (int i = 0; i < 10; i++) {
            DataInput inputData = new DataInput();
            inputData.setName("项目名称" + i);
            inputData.setInfo("项目信息" + i);
            inputData.setDescription("项目简介：这是一个安卓应用程序");
            data_list.add(inputData);
        }
    }
}
