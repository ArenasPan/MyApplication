package com.oschina.tianditu.myapplication;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by sina on 2015/7/20.
 */
public class NewFragment extends Fragment{
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View newFragment =inflater.inflate(R.layout.newproject_layout, container, false);
        return newFragment;
    }
}
